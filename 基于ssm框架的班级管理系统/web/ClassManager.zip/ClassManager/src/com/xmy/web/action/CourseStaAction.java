package com.xmy.web.action;

import com.xmy.service.ICourseService;
import com.xmy.service.IScoreService;

public class CourseStaAction extends BaseAction{
	
	private ICourseService courseService;
	private IScoreService scoreService;

}
